package com.nitesh.recycleview;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static RecyclerView recyclerView;
    private static MyAdapter adapter;
    private static List<Channel> data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler_view);
        data = new ArrayList<>();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyAdapter(data, this);
        recyclerView.setAdapter(adapter);

        fetchData();
    }

    private void fetchData() {
        String url = "https://raw.githubusercontent.com/niteshchavan/NTV/main/ntv.json";

        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONArray channelsArray = jsonObject.getJSONArray("NTV");
                        data.clear();

                        for (int i = 0; i < channelsArray.length(); i++) {
                            JSONObject channelObject = channelsArray.getJSONObject(i);
                            Channel channel = new Channel();
                            channel.setId(channelObject.getString("id"));
                            channel.setName(channelObject.getString("name"));
                            channel.setImage(channelObject.getString("image"));
                            channel.setUrl(channelObject.getString("url"));
                            data.add(channel);
                        }

                        adapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, "Error parsing data", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Toast.makeText(MainActivity.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                });

        queue.add(request);
    }

    public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {

        public LayoutInflater inflater;
        private List<Channel> data;
        private Context context;

        public MyAdapter(List<Channel> data, Context context) {
            this.data = data;
            this.context = context;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            // Inflate your item layout here (e.g., R.layout.item_channel)
            // Make sure the layout includes an ImageView for the channel image
            return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout, parent, false));
        }

        @Override
        public void onBindViewHolder(MyViewHolder holder, int position) {
            Channel channel = data.get(position);
            holder.channelName.setText(channel.getName());

            // Use Glide to load the image
            Glide.with(context)
                    .load(channel.getImage())
                    .into(holder.channelImage);
        }

        @Override
        public int getItemCount() {
            return data.size();
        }
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView channelName;
        ImageView channelImage;

        public MyViewHolder(View itemView) {
            super(itemView);
            channelName = itemView.findViewById(R.id.channel_name); // Replace with your TextView ID
            channelImage = itemView.findViewById(R.id.channel_image); // Replace with your ImageView ID
            // Set OnClickListener for channelName
            channelName.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (view.equals(channelName)) {
                // Get the position of the clicked item
                int position = getAdapterPosition();

                if (position != RecyclerView.NO_POSITION) {
                    // Access the corresponding Channel object
                    Channel channel = data.get(position);

                    // Display a toast message using the adapter's context (assuming adapter holds the context)
                    Toast.makeText(adapter.inflater.getContext(), "Channel " + channel.getName() + " Pressed", Toast.LENGTH_SHORT).show();

                    // You can perform other actions based on click here (e.g., navigate to a new activity)
                }
            }
        }
    }
}