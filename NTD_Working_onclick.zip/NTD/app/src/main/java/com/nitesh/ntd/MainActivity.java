package com.nitesh.ntd;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private MyAdapter adapter;
    private List<Channel> data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        data = new ArrayList<>();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyAdapter(data, this);
        recyclerView.setAdapter(adapter);

        fetchData();
    }

    private void fetchData() {
        String url = "https://raw.githubusercontent.com/niteshchavan/NTV/main/ntv.json";

        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONArray channelsArray = jsonObject.getJSONArray("NTV");
                        data.clear();

                        for (int i = 0; i < channelsArray.length(); i++) {
                            JSONObject channelObject = channelsArray.getJSONObject(i);
                            Channel channel = new Channel();
                            channel.setId(channelObject.getString("id"));
                            channel.setName(channelObject.getString("name"));
                            channel.setImage(channelObject.getString("image"));
                            channel.setUrl(channelObject.getString("url"));
                            data.add(channel);
                        }

                        adapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, "Error parsing data", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(MainActivity.this, "Error fetching data", Toast.LENGTH_SHORT).show());

        queue.add(request);
    }
}
